# Courtside

An English, tablet-first volleyball scoring companion for the supplied Ontario Volleyball Youth Best of 3 (Fall 2022) paper scoresheet. Designed for iPad and Redmi Pad in Chrome, with offline caching, browser-local match storage and JSON backups.

## Try locally

Run `npm start` from this directory, then open http://localhost:4173 in Chrome. Select **Try a practice match**. No dependency installation is needed; the application uses browser JavaScript, HTML and CSS. Python 3 is used only for the local development server, and Node.js for tests and packaging.

A local address is for this computer. A tablet needs the deployed HTTPS address for the full offline experience. `file://` is not supported. An ordinary HTTP LAN address does not enable service workers.

## Workflow

1. **Set up a match:** competition details, jersey numbers only, officials and paper checklist. Names and team leaders stay on the official roster stickers; the captain’s number is optional. Attach and verify both stickers on paper.
2. **Starting lineups:** confirm the toss, initial court sides, first service, six players in I–VI order and up to two designated liberos per team. Before each later set, explicitly choose **Keep current sides** or **Switch sides** (or select the left team) and confirm first service independently. Paper A/B letters stay fixed for the match; the printed set-2 columns are separate from actual court sides.
3. **Match centre:** use the team point buttons for played rallies. The buttons, names, colours, scores, timeout choices and team selectors follow actual left/right court positions as viewed from the scorer’s table. A side-out immediately ticks the new server’s service-round box. A set-winning score locks further rally and penalty points; Undo or correction can reopen scoring, and Confirm set result records the referee-confirmed end. Timeout and Substitution record requesting-team-first scores. Other events contains libero exchanges, sanctions, remarks and no-serve penalty points.
4. **Paper guide:** copy the shown marks to the original paper. Blue entries represent the recorded history; gold highlights the most recent change. Timeout and substitution views zoom to the relevant section. Full scoresheet and Enlarge provide context.
5. **Corrections:** Undo reverses the complete last event. History can reassign, remove or insert a rally. All later events are replayed and validated; a change that invalidates a later substitution, court change or finalized set is blocked. Undo dependent events first, then re-enter them. Corrections are audited and require a paper review acknowledgement.
6. **Finish:** confirm each set with its actual end time. Review the post-match checklist and paper signatures. Export a JSON backup, and optionally Print / Save PDF through the browser. After the whole match is confirmed, Enlarge opens the entire sheet in a full-page viewer, including all sets and results, regardless of the previously selected paper section. Use + / − to zoom and scroll, Fit sheet to see the whole page, and Close to return. The same viewer is available from the post-match checklist.

## Deleting saved matches

Each row in **Saved matches** shows the confirmed match winner, overall set score and each set’s point score, always in the displayed team order. Unfinished matches show their current status and label unfinished sets. Each row also has a separate **Delete** button. Confirm the displayed teams, date and match details to permanently remove that match from this browser. Deleting the active match also clears its active reference so later saves do not recreate it. Other matches, club rosters and previously exported backup files are kept.

## Saved club rosters

In **Team rosters**, jersey numbers appear as compact chips in rows of six; the seventh number starts the next row. Use **Save club roster** to store a labelled squad with its team name, short code, jersey numbers and optional captain. For the next match, select the intended team tab and use **Load club roster**. Existing entries require a replacement confirmation; loading clears that team’s draft starting lineup/liberos and resets roster/signature checks. Rosters cannot be loaded after match events exist.

Use separate labels for different ages or seasons. Saving the same label (ignoring case) updates that saved club roster. Deleting a saved club roster leaves existing matches intact. Club rosters live in this browser’s local match library, survive refresh/reopening, and are not automatically synced between devices or included in individual match-backup files.

## Offline, storage and updates

- Open online once and wait for **Offline ready** before arriving at the venue.
- Keep the same browser profile and URL. Local storage is device-specific and may be cleared by private browsing, storage pressure or clearing browsing data.
- Export backups during and after a match. An import creates a separate saved match when the ID already exists. New matches do not require player names. Older backups may still contain names; these are retained when imported but are not printed over the roster sticker area.
- Do not use multiple tabs to record simultaneously. If another tab writes to the library, this tab blocks further changes until reloaded.
- If saving fails, a persistent **Not saved** status and notification appear; export immediately.
- Updates are cached in the background and activate after all old Courtside tabs close. Do this between matches after exporting a backup. For a new release, change the matching cache name in `sw.js` and `app.js`, and keep the stylesheet/module version URLs in `index.html` and `sw.js` aligned. The current release is v13, shown in the home-page footer. Documents use the network when available; offline requests fall back to the cached release.
- The website serves application files only. No player data is uploaded; there are no analytics, external fonts, trackers or remote runtime dependencies.

## Free GitHub Pages deployment

1. Run `node scripts/package.mjs` (or `npm run build`). The deployable files are in `dist/`.
2. Sign in to GitHub and create a public repository, for example `courtside-scorer`.
3. Upload **the contents of `dist/`**, keeping the `assets/` subfolder; `index.html` must be at the repository root.
4. In the repository open **Settings → Pages → Build and deployment → Deploy from a branch**, select **main** and **/(root)**, then Save.
5. Open the HTTPS site address returned by GitHub Pages. All asset and offline paths are relative, so project subpaths work without configuration.
6. On each tablet, open the deployed address online and wait for **Offline ready**. Test a practice match and refresh while offline before using it at a real event.

No custom domain, database, paid server or backend account is needed. GitHub account sign-in is required to publish. Only deploy application files, never real match backups.

## Verification

`npm test` runs 33 regression tests covering immediate service ticks, score locks and undo/corrections, 25-point and 15-point deuce, actual versus paper court positions, confirmed court changes and all three deciding-set modes, sticker rendering, legacy backups, duplicate lineup prevention, and the existing timeout/substitution/libero behavior.

The current update was checked with Node regression tests, JavaScript syntax checks and static packaging. Browser interaction and device testing are being done by the user; no browser was controlled for this update.

## Rules and limits

Default profile: 18U, best of three; sets 1–2 to 25 and set 3 to 15, win by two; deciding-set court change reminder at 8 by default; two timeouts and six limited substitutions per team per set. The second referee should confirm event variations. Scoring-format settings lock after play starts. For set 3, choose a score-based reminder, a manual change on referee instruction, or no mid-set court change before the set starts. A score-based reminder pauses further scoring until the change is confirmed; it does not move buttons automatically. A confirmed change moves actual sides while preserving service order. Undo restores the prior sides. Set 3 still targets 15 points regardless of the court-change mode.

Two liberos per set are supported in line with the OVA 2026–27 update. Libero timing, sanctions, exceptional substitutions, expelled/disqualified player replacements and complex referee-directed cancellations require the scorer and second referee to confirm the procedure. The referee-directed exceptional substitution form updates the service-order slot, logs a remark and excludes the outgoing player from the rest of the match. Further substitutions in that slot require referee-directed handling. Exceptional substitutions count in results totals, but not against the ordinary substitution limit.

The original left section of set 3 freezes when courts change. The far-right continuation repeats the starting lineup and substitute numbers; previous timeout scores, substitution scores and service-turn exits remain in the original section. Subsequent points and exits use the continuation. The original left grid only has 8 points; no-change or late manual changes may require a referee-directed continuation sheet. If the printed point/service grid is exhausted, an explicit warning requests a referee-directed continuation sheet; the event backup still retains everything.

The app does not adjudicate faults, create signatures or replace the official paper record. Verify its paper examples with a trained scorer before live use.

Sources reviewed November 23, 2026:

- User-supplied `OVA_Best_of_3_Scoresheet_-_FALL_2022_V1.pdf` (background rendered to `assets/ova-scoresheet.png`; OVA branding and form belong to their respective owner).
- [Volleyball Canada 2026–27 Official Rules](https://volleyball.ca/uploads/Development/Referee/Rules/Rulebook_Files/Current_Year/2026-27_VC_Rulebook_EN.pdf), especially rules 15, 18 and 19.
- [Volleyball Canada scorekeeper training](https://volleyball.ca/uploads/Development/Referee/Rules/Volleyball_Canada_Score_Sheet_Presentation_v3.5.pdf), including the deciding-set continuation procedure.
- [OVA 2026–27 updates](https://cdn1.sportngin.com/attachments/document/0b78-2477362/What_s_New_26-27_FINAL_V1.2.pdf), 18U two-libero change.
